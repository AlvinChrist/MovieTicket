import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:movie_ticket/components/bookmark_icon.dart';
import 'package:movie_ticket/consts/colors.dart';
import 'package:movie_ticket/pages/reservation.dart';

class DetailPage extends StatelessWidget {
  int index = 0;
  final Map<String,dynamic> movie;
  DetailPage({Key? key, required this.movie, required this.index}) : super(key: key);
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          color: primaryBlack,
          image: DecorationImage(
            alignment: Alignment.topCenter,
            image: AssetImage(movie['img']),
            fit: BoxFit.fitWidth,
          ),
        ),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget> [
              Padding(
                padding: const EdgeInsets.fromLTRB(20,35,20,20),
                child:  Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget> [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: primaryBlack.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(15.0)
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.chevron_left,
                          size: 32.0,
                          color: primaryWhite,
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      )
                    ),
                    BookmarkIcon(movie: movie)
                  ],
                ),
              ),
              Expanded(
                child:Container(
                  decoration: BoxDecoration(
                    color: primaryBlack,
                    gradient: LinearGradient(
                      end: const Alignment(0.0, -0.9),
                      begin: const Alignment(0.0, -0.4),
                      colors: <Color>[
                        primaryBlack,
                        primaryBlack.withOpacity(0.95),
                        primaryBlack.withOpacity(0.9),
                        primaryBlack.withOpacity(0.85),
                        primaryBlack.withOpacity(0.8),
                        primaryBlack.withOpacity(0.75),
                        primaryBlack.withOpacity(0.7),
                        primaryBlack.withOpacity(0.65),
                        primaryBlack.withOpacity(0.6),
                        primaryBlack.withOpacity(0.55),
                        primaryBlack.withOpacity(0.5),
                        primaryBlack.withOpacity(0.45),
                        primaryBlack.withOpacity(0.4),
                        primaryBlack.withOpacity(0.35),
                        primaryBlack.withOpacity(0.3),
                        primaryBlack.withOpacity(0.25),
                        primaryBlack.withOpacity(0.2),
                        primaryBlack.withOpacity(0.15),
                        primaryBlack.withOpacity(0.1),
                        primaryBlack.withOpacity(0.05),
                        primaryBlack.withOpacity(0)
                      ],
                    )
                  ),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(20,(MediaQuery.of(context).size.height - 85) * 0.3,20,20),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget> [
                          Wrap(
                            children: <Widget> [
                              Text(movie['title'],
                                style: const TextStyle(
                                  fontSize: 32.0,
                                  fontWeight: FontWeight.bold
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 30),
                            child:  Wrap(
                              children: <Widget> [
                                Text(movie['desc'],
                                  style: const TextStyle(
                                    color: primaryWhite,
                                    fontSize: 14.0,
                                    height: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Wrap(
                            children: <Widget>[
                              const Text('Director: '),
                              Text(List<String>.from(movie['director']).join(','), style: const TextStyle(fontWeight: FontWeight.bold),)
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Wrap(
                            children: <Widget>[
                              const Text('Writers: '),
                              Text(List<String>.from(movie['writer']).join(','), style: const TextStyle(fontWeight: FontWeight.bold))
                            ],
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          const Divider(
                            color: primaryWhite,
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          const Text('Starring',
                            style: TextStyle(
                              fontSize: 20.0,
                              fontWeight: FontWeight.bold
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          SizedBox(
                            height: 50,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemCount: movie['starring'].length,
                              itemBuilder: (context, index) {
                                return Row(
                                  children: <Widget>[
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(8.0),
                                      child: Image.asset('assets/starring/${movie['starring'][index]['name']}.jpg',
                                        width: 50,
                                        height: 50,
                                      )
                                    ),
                                    const SizedBox(width: 10,),
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: <Widget> [
                                        Text(movie['starring'][index]['name'],
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold
                                          )
                                        ),
                                        Text(movie['starring'][index]['characterName'])
                                      ],
                                    ),
                                    const SizedBox(width: 20,),
                                  ],
                                );
                              }
                            ),
                          ),
                          const SizedBox(height: 25,),
                        ],
                      ),
                    )
                  ),
                )
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget> [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20,0,20,20),
                      child: ElevatedButton(
                        onPressed: (){
                          // inspect(movie);
                          Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Reservation(movie: movie, index: index))
                          );
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(primaryGold),
                        ),
                        child: const Text('Reservation',
                          style: TextStyle(
                            fontWeight: FontWeight.w600
                          )
                        ),
                      ),
                    )
                  )
                ],
              )
            ],
          ),
      ),
    );
  }
}