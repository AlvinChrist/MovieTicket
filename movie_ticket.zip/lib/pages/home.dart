import 'package:flutter/material.dart';
import 'package:movie_ticket/components/categories.dart';
import 'package:movie_ticket/components/search_bar.dart';
import 'package:movie_ticket/consts/colors.dart';
import 'package:movie_ticket/consts/data.dart';

import '../components/carousel.dart';
import 'detail.dart';

class MyHome extends StatelessWidget {
  const MyHome({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context){
    bool notifyMe = false;
    return SafeArea(
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        color: primaryBlack,
        child: CustomScrollView(
          slivers: <Widget>[
            SliverList(
              delegate: SliverChildListDelegate(
                [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(15, 30, 15, 0),
                    child: Column(
                      children: <Widget> [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget> [
                            Expanded(
                              child: Wrap(
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: const <Widget> [
                                      Text('Welcome Alvin',
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text('What movie are we going to see today?',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const CircleAvatar(
                              backgroundColor: primaryOrange,
                              child: Text('A',
                                style: TextStyle(
                                  color: primaryWhite
                                )
                              ),
                            )
                          ]
                        ),
                        const SizedBox(height: 25,),
                        const MySearchBar()
                      ],
                    )
                  ),
                  SizedBox(
                    height: 70,
                    child: Categories(),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(left: 15, top: 30, bottom: 15),
                    child: Text('Showing this month',
                      style: TextStyle(
                        color: primaryWhite,
                        fontWeight: FontWeight.bold,
                        fontSize: 26
                      )
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.556,
                    child: const CarouselWithIndicatorDemo()
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Movies',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 26
                          ),
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Wrap(
                              children: const [
                                Text('Notify me on updates')
                              ],
                            ),
                            MySwitch(
                              state: notifyMe,
                              onChange: (val){
                                notifyMe = val;
                              },
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
              delegate: SliverChildBuilderDelegate((context, index) {
                return Container(
                  margin: const EdgeInsets.all(5.0),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.all(Radius.circular(5.0)),
                    child: GestureDetector(
                      onTapUp: (details) {
                        Navigator.push(context, 
                          MaterialPageRoute(builder: (context) => DetailPage(movie: movieDesc[index], index: index))
                        );
                      },
                      child: Stack(
                        children: <Widget>  [
                          Image.asset(movieDesc[index]['img'], fit: BoxFit.fitHeight, width: 1000.0),
                          Positioned(
                            bottom: 0.0,
                            left: 0.0,
                            right: 0.0,
                            child: Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.fromARGB(200, 0, 0, 0),
                                    Color.fromARGB(0, 0, 0, 0)
                                  ],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                ),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
                                child: Text(movieDesc[index]['title'],
                                  style: const TextStyle(
                                    fontSize: 12.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                    )
                  ),
                );
              },
              childCount: movieDesc.length
              )
            ),
          ],
        )
      ),
    );
  }
}

class MySwitch extends StatefulWidget{
  final bool state;
  final Function(bool value) onChange;

  const MySwitch({Key? key, required this.state, required this.onChange}) : super(key: key);
  @override
  State<MySwitch> createState() => _MySwitchState();
}

class _MySwitchState extends State<MySwitch> {
  bool _state = false;
  @override
  void initState(){
    _state = widget.state;
    super.initState();
  }
  @override
  Widget build(BuildContext context){
    return Switch(
      inactiveTrackColor: primaryGrey,
      activeColor: primaryOrange,
      value: _state, 
      onChanged: (val){
        _state = val;
        setState(() {
          widget.onChange(val);
        });
      }
    );
  }
}