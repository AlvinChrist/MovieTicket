import 'package:flutter/material.dart';
const Color primaryOrange = Color(0xFFFF843A);
const Color primaryGold = Color.fromRGBO(222, 157, 52, 1);
const Color primaryWhite = Color(0xFFF5F6F8);
const Color primaryBlack = Color(0xFF21242C);
const Color primaryGrey = Color(0xFF77787A);
const Color darkOrange = Color(0xff906C33);